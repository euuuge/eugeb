def calcular_area_triangulo(base, altura):
    return(base*altura) /2
base=float(input("ingresa la base del triangulo:"))
altura=float(input("ingresa la altura del triangulo:"))
area=calcular_area_triangulo(base,altura)
print("el area del trianguloes", area)