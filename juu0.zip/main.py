def suma(valor1,valor2):
    return valor1+valor2
resultado=suma(4,5)
print(resultado)
