# area de un triangulo 
def multiplicacion(base1,altura2):
     return base1*altura2
resultado=multiplicacion (7,9)
print(resultado)
 